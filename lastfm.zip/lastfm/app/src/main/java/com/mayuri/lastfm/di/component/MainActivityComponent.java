package com.mayuri.lastfm.di.component;

import android.content.Context;

import com.mayuri.lastfm.di.module.AdapterModule;
import com.mayuri.lastfm.di.qualifier.ActivityContext;
import com.mayuri.lastfm.di.scope.ActivityScope;
import com.mayuri.lastfm.ui.MainActivity;

import dagger.Component;


@ActivityScope
@Component(modules = AdapterModule.class, dependencies = ApplicationComponent.class)
public interface MainActivityComponent {

    @ActivityContext
    Context getContext();


    void injectMainActivity(MainActivity mainActivity);


}
