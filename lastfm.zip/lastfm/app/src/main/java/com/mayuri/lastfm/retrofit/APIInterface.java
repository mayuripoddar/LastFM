package com.mayuri.lastfm.retrofit;

import com.mayuri.lastfm.pojo.Lastfm;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIInterface {


   // @GET ("?method=album.search&album='{userInput}'&api_key=00b49401c799a92996db257a81aaa3a7&format=json")
    //Call<Lastfm> getLastfm(@Query("userInput") String userInput);

    @GET ("?method=album.search&album=life&api_key=00b49401c799a92996db257a81aaa3a7&format=json")
    Call<Lastfm> getLastfm();



}
