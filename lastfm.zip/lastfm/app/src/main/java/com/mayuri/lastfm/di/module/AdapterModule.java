package com.mayuri.lastfm.di.module;


import com.mayuri.lastfm.adaptor.RecyclerViewAdapter;
import com.mayuri.lastfm.ui.MainActivity;
import com.mayuri.lastfm.di.scope.ActivityScope;

import dagger.Module;
import dagger.Provides;

@Module(includes = {MainActivityContextModule.class})
public class AdapterModule {

    @Provides
    @ActivityScope
    public RecyclerViewAdapter getAlbumLIst(RecyclerViewAdapter.ClickListener clickListener) {
        return new RecyclerViewAdapter(clickListener);
    }

    @Provides
    @ActivityScope
    public RecyclerViewAdapter.ClickListener getClickListener(MainActivity mainActivity) {
        return (RecyclerViewAdapter.ClickListener) mainActivity;
    }
}
