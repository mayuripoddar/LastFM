package com.mayuri.lastfm.di.qualifier;

import javax.inject.Qualifier;

@Qualifier
public @interface ActivityContext {

}
